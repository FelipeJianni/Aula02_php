<?php
    namespace app\database\models;

    class Student extends Model {
        protected $table = 'students';
    }